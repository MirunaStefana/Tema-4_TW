import React from "react"
import { useState } from "react"

function RobotForm() {
    const [name, setName] = useState([])
    const [type, setType] = useState([])
    const [mass, setMass] = useState([])
    return (
        <div>
            <form>
                <h1>Robot form</h1>

                <p>test</p>

                <input aria-label="name" type = 'text' id = 'name' name = 'name' value={name} onChange={(e) => {setName(e.target.value)}}></input>
                <input aria-label="type" type = 'text' id = 'type' name = 'type' value={type} onChange={(e) => {setType(e.target.value)}}></input>
                <input aria-label="mass" type = 'text' id = 'mass' name = 'mass' value={mass} onChange={(e) => {setMass(e.target.value)}}></input>
                
                <button aria-label="button" value = 'add' onClick={(e) => { e.preventDefault()
                setName("") 
                setType("") 
                setMass("")}}></button>
            </form>
        </div>
    )
}

export default RobotForm