#TOPIC: REACT

# Having the following application developed using React complete the project so that :

- The application renders without crashing; (0.5 pts)
- A RobotForm component is rendered; (0.5 pts)
- The RobotForm has inputs for `name`, `type` și `mass` (0.5 pts)
- Given that the inputs for the robot properties have the ids `name`, `type` and `mass` and that the add button has the value `add` a robot can be successfully added;(0.5 pts)
- After adding a robot, the fields are reset to their initial value (0.5 pts)